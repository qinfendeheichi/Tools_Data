package com.example.testhasignores;

public class Mutee {

  public static int returnOne() {
    return 1;
  }

}
