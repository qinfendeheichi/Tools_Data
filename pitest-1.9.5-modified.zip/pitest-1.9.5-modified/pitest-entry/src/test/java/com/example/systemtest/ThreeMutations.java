package com.example.systemtest;

public class ThreeMutations {
    public static int returnOne() {
        return 1;
    }

    public static int returnTwo() {
        return 2;
    }

    public static int returnThree() {
        return 3;
    }
}
